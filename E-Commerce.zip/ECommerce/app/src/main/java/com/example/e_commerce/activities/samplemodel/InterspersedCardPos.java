package com.example.e_commerce.activities.samplemodel;

import com.google.gson.annotations.SerializedName;

public class InterspersedCardPos{

	@SerializedName("ROM")
	private int rOM;

	@SerializedName("Memori Internal")
	private int memoriInternal;

	@SerializedName("Ukuran")
	private int ukuran;

	@SerializedName("Optical Zoom")
	private int opticalZoom;

	@SerializedName("Kondisi Produk")
	private int kondisiProduk;

	@SerializedName("Lokasi toko")
	private int lokasiToko;

	@SerializedName("Warna")
	private int warna;

	@SerializedName("RAM")
	private int rAM;

	public void setROM(int rOM){
		this.rOM = rOM;
	}

	public int getROM(){
		return rOM;
	}

	public void setMemoriInternal(int memoriInternal){
		this.memoriInternal = memoriInternal;
	}

	public int getMemoriInternal(){
		return memoriInternal;
	}

	public void setUkuran(int ukuran){
		this.ukuran = ukuran;
	}

	public int getUkuran(){
		return ukuran;
	}

	public void setOpticalZoom(int opticalZoom){
		this.opticalZoom = opticalZoom;
	}

	public int getOpticalZoom(){
		return opticalZoom;
	}

	public void setKondisiProduk(int kondisiProduk){
		this.kondisiProduk = kondisiProduk;
	}

	public int getKondisiProduk(){
		return kondisiProduk;
	}

	public void setLokasiToko(int lokasiToko){
		this.lokasiToko = lokasiToko;
	}

	public int getLokasiToko(){
		return lokasiToko;
	}

	public void setWarna(int warna){
		this.warna = warna;
	}

	public int getWarna(){
		return warna;
	}

	public void setRAM(int rAM){
		this.rAM = rAM;
	}

	public int getRAM(){
		return rAM;
	}

	@Override
 	public String toString(){
		return 
			"InterspersedCardPos{" + 
			"rOM = '" + rOM + '\'' + 
			",memori Internal = '" + memoriInternal + '\'' + 
			",ukuran = '" + ukuran + '\'' + 
			",optical Zoom = '" + opticalZoom + '\'' + 
			",kondisi Produk = '" + kondisiProduk + '\'' + 
			",lokasi toko = '" + lokasiToko + '\'' + 
			",warna = '" + warna + '\'' + 
			",rAM = '" + rAM + '\'' + 
			"}";
		}
}