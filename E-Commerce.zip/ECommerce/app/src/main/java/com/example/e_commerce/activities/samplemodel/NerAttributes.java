package com.example.e_commerce.activities.samplemodel;

import com.google.gson.annotations.SerializedName;

public class NerAttributes{

	@Override
 	public String toString(){
		return 
			"NerAttributes{" + 
			"}";
		}
}