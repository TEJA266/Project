package com.example.e_commerce.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_commerce.R;
import com.example.e_commerce.activities.samplemodel.Data;
import com.example.e_commerce.activities.samplemodel.ProductInfo;
import com.example.e_commerce.activities.samplemodel.ProductsItem;
import com.example.e_commerce.adapters.LinearRecycleViewProductsAdapter;
import com.example.e_commerce.adapters.ProductAdapterInterface;
import com.example.e_commerce.apiinterfaces.ApiInterface;
import com.example.e_commerce.applications.ApplicationClass;
import com.google.gson.Gson;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ProductLinearListingPageActivity extends AppCompatActivity implements ProductAdapterInterface {
        List<ProductsItem> productDetailsList = new ArrayList<>();
        RecyclerView recyclerView;
    ImageButton cartButton ;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycler_view_product_listing);
        recyclerView = findViewById(R.id.recycler_view);
        Toolbar toolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
//        Toolbar toolbar = findViewById(R.id.my_toolbar);
//        setSupportActionBar(toolbar);
//        cartButton =findViewById(R.id.cart_icon);
//        cartButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent goToCart = new Intent(ProductLinearListingPageActivity.this,CartDetailsActivity.class);
//                startActivity(goToCart);
//            }
//        });
        Retrofit retrofit ;
        //Making the api call for the products
        ApiInterface mApiInterface = ApplicationClass.retrofit.create(ApiInterface.class);
        mApiInterface.getProducts("samsung",false,20,0,0).enqueue(new Callback<ProductInfo>() {
            @Override
            public void onResponse(Call<ProductInfo> call, Response<ProductInfo> response) {
                if(response.isSuccessful() && response.body()!=null)
                {
                    if (response.isSuccessful() && response.body() != null) {
                        Data data = response.body().getData();
                        productDetailsList = data.getProducts();
                        Log.i("SUCCESS_LINEAR", response.body().toString());
                    }

                    recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext()));
                    recyclerView.setAdapter(new LinearRecycleViewProductsAdapter(productDetailsList,ProductLinearListingPageActivity.this));

                    Log.i("SUCCESSFULL","API CALLED SUCCESSFULLY!!");
                }
                else {
                    Log.i("FAILED","FAILED TO CALL API !!");
                }
            }

            @Override
            public void onFailure(Call<ProductInfo> call, Throwable t) {
                Log.i("FAILED","FAILED TO CALL API !!");
            }
        });


    }


    @Override
    public void clickToSeeDetails(ProductsItem productsItem) {

        Gson gson = new Gson();
        Intent goToProductDetailsPage = new Intent(ProductLinearListingPageActivity.this,ProductDetailsActivity.class);

        goToProductDetailsPage.putExtra("items", productsItem);
        startActivity(goToProductDetailsPage);
    }

    @Override
    public void deleteTheItem(ProductsItem productsItem) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.go_to_cart) {
            Intent goToCart = new Intent(ProductLinearListingPageActivity.this,CartDetailsActivity.class);
            startActivity(goToCart);
        }

        return super.onOptionsItemSelected(item);
    }
}
