package com.example.e_commerce.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.e_commerce.BaseActivity;
import com.example.e_commerce.R;

public class HomePageActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);
        Toolbar toolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.cart_menu);
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == R.id.go_to_cart) {
                    Intent goToCart = new Intent(HomePageActivity.this, CartDetailsActivity.class);
                    startActivity(goToCart);

                }
                return false;
            }
        });
        EditText username = findViewById(R.id.et_enter_username);
        EditText password = findViewById(R.id.et_enter_password);
        Button login = findViewById(R.id.btn_login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeToProduct = new Intent(HomePageActivity.this,ProductLinearListingPageActivity.class);
                startActivity(homeToProduct);
            }
        });


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.go_to_cart) {
//          Intent goToCart = new Intent(HomePageActivity.this, CartDetailsActivity.class);
//            startActivity(goToCart);
        }

        return super.onOptionsItemSelected(item);
    }



}