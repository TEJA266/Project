package com.example.e_commerce.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.example.e_commerce.R;
import com.example.e_commerce.activities.samplemodel.ProductsItem;
import com.google.gson.Gson;

import java.util.HashMap;

public class ProductDetailsActivity extends AppCompatActivity {

    HashMap<ProductsItem, Boolean> ifExists = new HashMap<>();
    static int inserts =0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_details_layout);

        Toolbar toolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        SharedPreferences cartItems = getApplication().getSharedPreferences("cart", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = cartItems.edit();



        //Declarations of the view elements

        ImageView productImage;
        TextView productName,priceView,desc1,desc2,desc3,desc4;

        //Calling the intents for the Elements


        Intent i = getIntent();
        ProductsItem productsItem = (ProductsItem)(i.getSerializableExtra("items"));
        String im_url = productsItem.getImages().get(0);
        String name = productsItem.getName();
        String price = productsItem.getPrice().getPriceDisplay();
        String id = productsItem.getId();
        String status = productsItem.getStatus();
        String brand = productsItem.getBrand();
        String merchant = productsItem.getMerchantName();

        //Initializing the elements

        productImage = findViewById(R.id.iv_product_image);
        Glide.with(productImage.getContext()).load(im_url).into(productImage);

        productName = findViewById(R.id.tv_product_details_name);
        productName.setText(name);

        priceView =findViewById(R.id.tv_product_details_price);
        priceView.setText(price);

        desc1 = findViewById(R.id.tv_product_details_desc1);
        desc1.setText(id);


        desc2 = findViewById(R.id.tv_product_details_desc2);
        desc2.setText(status);


        desc3 = findViewById(R.id.tv_product_details_desc3);
        desc3.setText(brand);


        desc4 = findViewById(R.id.tv_product_details_desc4);
        desc4.setText(merchant);


        Button addToCart = findViewById(R.id.btn_product_details_add_to_cart);
        addToCart.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {

                if (!ifExists.containsKey(productsItem)){
                    ifExists.put(productsItem, true);
                    inserts++;
                    Gson gson1 = new Gson();
                    Toast.makeText(v.getContext(), "Item  Added!!", Toast.LENGTH_SHORT).show();
                    editor.putString(String.valueOf(inserts), gson1.toJson(productsItem));
                    editor.commit();
                } else {
                    addToCart.setBackgroundColor(R.color.button_change_bg);

                    editor.remove(String.valueOf(inserts));
                    editor.commit();
                    Toast.makeText(v.getContext(), "Item already Added!!", Toast.LENGTH_SHORT).show();
                }
//                Intent goToCart = new Intent(ProductDetailsActivity.this,CartDetailsActivity.class);
//                startActivity(goToCart);

//                if(addToCart.isActivated())
//                {
//
//                    addToCart.setBackgroundColor(R.color.button_change_bg);
//                    Toast.makeText(ProductDetailsActivity.this,"Product Added to Cart!",Toast.LENGTH_SHORT).show();
//                    addToCart.setActivated(false);
//                }
//                else {
//                    addToCart.setBackgroundColor(R.color.button_bg);
//                    addToCart.setActivated(true);
//                    Toast.makeText(ProductDetailsActivity.this,"Product Removed from Cart!",Toast.LENGTH_SHORT).show();
//                }
            }
        });

        Button buyNow = findViewById(R.id.btn_product_details_buy_now);
        buyNow.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                if(buyNow.isActivated())
                {

                buyNow.setBackgroundColor(R.color.button_change_bg);
                Toast.makeText(ProductDetailsActivity.this,"Order Placed Successfully!",Toast.LENGTH_SHORT).show();
                buyNow.setActivated(false);
                }
                else {
                    buyNow.setBackgroundColor(R.color.button_bg);
                    buyNow.setActivated(true);
                    Toast.makeText(ProductDetailsActivity.this,"Order UnPlaced Successfully!",Toast.LENGTH_SHORT).show();
                }
            }
        });









    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.go_to_cart) {
            Intent goToCart = new Intent(ProductDetailsActivity.this,CartDetailsActivity.class);
            startActivity(goToCart);
        }

        return super.onOptionsItemSelected(item);
    }
}
