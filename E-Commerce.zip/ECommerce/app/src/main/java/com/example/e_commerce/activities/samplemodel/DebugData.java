package com.example.e_commerce.activities.samplemodel;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class DebugData  implements Serializable {

	@Override
 	public String toString(){
		return 
			"DebugData{" + 
			"}";
		}
}