package com.example.e_commerce.adapters;

import com.example.e_commerce.activities.samplemodel.ProductsItem;

public interface ProductAdapterInterface {
        void clickToSeeDetails(ProductsItem productsItem);

        void deleteTheItem(ProductsItem productsItem);

}
