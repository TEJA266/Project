package com.example.e_commerce.constants;

public class Constants {
    public static final String  BASE_URL= "https://www.blibli.com/";
}
