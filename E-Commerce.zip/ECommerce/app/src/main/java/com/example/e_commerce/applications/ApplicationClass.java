package com.example.e_commerce.applications;

import android.app.Application;

import com.example.e_commerce.constants.Constants;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApplicationClass extends Application {
    public static Retrofit retrofit;
    @Override
    public void onCreate() {
        super.onCreate();

        retrofit = createRetrofitObject();


    }


    public Retrofit createRetrofitObject()
    {
        okhttp3.OkHttpClient client = new OkHttpClient.Builder().build();
        if(retrofit==null)
        {

                retrofit = new Retrofit.Builder()
                        .client(client)
                        .baseUrl(Constants.BASE_URL)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();
        }
        return retrofit;

    }
}
