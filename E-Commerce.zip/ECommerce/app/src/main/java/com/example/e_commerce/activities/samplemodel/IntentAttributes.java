package com.example.e_commerce.activities.samplemodel;

import com.google.gson.annotations.SerializedName;

public class IntentAttributes{

	@Override
 	public String toString(){
		return 
			"IntentAttributes{" + 
			"}";
		}
}