package com.example.e_commerce.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_commerce.R;
import com.example.e_commerce.activities.samplemodel.ProductsItem;
import com.example.e_commerce.adapters.CartListRecycleViewAdapter;
import com.example.e_commerce.adapters.ProductAdapterInterface;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class CartDetailsActivity extends AppCompatActivity implements ProductAdapterInterface {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycler_view_cart_details);

        Toolbar toolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);

        Gson gson  = new Gson();
        SharedPreferences sharedPreferences = getApplication().getSharedPreferences("cart", Context.MODE_PRIVATE);

        int inserts = ProductDetailsActivity.inserts;
        RecyclerView rvList = findViewById(R.id.rv_cart_details);
        List<ProductsItem> items = new ArrayList<>();
        for (int i=1;i<=inserts;i++)

        {if(sharedPreferences.getString(String.valueOf(i), null)!=null)
        {

            Log.i("HURRAHHHHHH  "+String.valueOf(i),sharedPreferences.getString(String.valueOf(i),null));
            String json = sharedPreferences.getString(String.valueOf(i), null);
            ProductsItem obj = gson.fromJson(json, ProductsItem.class);
            items.add(obj);
//            Log.i("SUCCESSJSON",items.get(i-1).toString());
        }
        }
        rvList.setLayoutManager(new LinearLayoutManager(this));
        rvList.setAdapter(new CartListRecycleViewAdapter(items,CartDetailsActivity.this));

    }

    @Override
    public void clickToSeeDetails (ProductsItem productsItem){
        Gson gson = new Gson();
        Intent i = new Intent(CartDetailsActivity.this, ProductDetailsActivity.class);
        i.putExtra("items", productsItem);

        startActivity(i);

    }

    @Override
    public void deleteTheItem(ProductsItem productsItem) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.go_to_cart) {
            Toast.makeText(CartDetailsActivity.this,"You are already in cart!",Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }
}



