package com.example.e_commerce.apiinterfaces;

import com.example.e_commerce.activities.samplemodel.ProductInfo;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;

public interface ApiInterface {
    @Headers({"user-agent: BlibliAndroid/0.0.1"})
    @GET("/backend/search/products")
    Call<ProductInfo> getProducts(@Query("searchTerm") String Term, @Query("showFacets") boolean facets, @Query("itemPerPage") int items, @Query("page") int page, @Query("start") int start);

}
