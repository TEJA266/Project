package com.example.e_commerce;

import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.e_commerce.activities.CartDetailsActivity;
import com.example.e_commerce.activities.HomePageActivity;

public class BaseActivity extends AppCompatActivity {
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.go_to_cart) {
//          Intent goToCart = new Intent(HomePageActivity.this, CartDetailsActivity.class);
//            startActivity(goToCart);
        }

        return super.onOptionsItemSelected(item);
    }
}
