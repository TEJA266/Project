package com.example.e_commerce.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.e_commerce.R;
import com.example.e_commerce.activities.samplemodel.ProductsItem;

import java.util.List;

public class CartListRecycleViewAdapter extends RecyclerView.Adapter<CartListRecycleViewAdapter.ProductViewHolder> {
    ProductAdapterInterface productAdapterInterface;
    List<ProductsItem> list;
    public CartListRecycleViewAdapter(List<ProductsItem> list,ProductAdapterInterface productAdapterInterface)
    {
        this.list = list;
        this.productAdapterInterface = productAdapterInterface;
    }

    @NonNull
    @Override
    public CartListRecycleViewAdapter.ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_layout, parent, false);
        return new CartListRecycleViewAdapter.ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartListRecycleViewAdapter.ProductViewHolder holder, int position) {
        holder.bind(list.get(position));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ProductViewHolder extends RecyclerView.ViewHolder {
        View view;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    productAdapterInterface.clickToSeeDetails(list.get(getAdapterPosition()));
                }
            });


        }

        public void bind(ProductsItem productsItem) {
//            String id = productsItem.getId().toString();
            String im_url = productsItem.getImages().get(0);
//            String brand = productsItem.getBrand().toString();
//            String price = productsItem.getPrice().getPriceDisplay();
//
            if(view!=null)
            {

                ImageView imageView = view.findViewById(R.id.iv_card_image_linear);
//
                Glide.with(imageView.getContext()).load(im_url).into(imageView);

                TextView textView = view.findViewById(R.id.tv_listing_page_prd_name);
                textView.setText("BliBli");

                TextView textView2 = view.findViewById(R.id.tv_listing_page_prd_price);
                textView2.setText("50000");

                TextView textView1 = view.findViewById(R.id.tv_listing_page_merchant_det);
                textView1.setText("amazon Basics");
            }
        }
    }
}



