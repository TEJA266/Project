package com.example.e_commerce.activities.samplemodel;

import com.google.gson.annotations.SerializedName;

public class ProductInfo{

	@SerializedName("code")
	private int code;

	@SerializedName("data")
	private Data data;

	@SerializedName("status")
	private String status;

	@SerializedName("BLP-60045-00314")
	private BLP6004500314 bLP6004500314;

	@SerializedName("GAT-70141-00001")
	private GAT7014100001 gAT7014100001;

	@SerializedName("GRP-70138-00004")
	private GRP7013800004 gRP7013800004;

	@SerializedName("SAO-60034-01683")
	private SAO6003401683 sAO6003401683;

	@SerializedName("SAO-60034-02002")
	private SAO6003402002 sAO6003402002;

	@SerializedName("SAO-60034-01684")
	private SAO6003401684 sAO6003401684;

	@SerializedName("SAO-60034-01468")
	private SAO6003401468 sAO6003401468;

	public void setCode(int code){
		this.code = code;
	}

	public int getCode(){
		return code;
	}

	public void setData(Data data){
		this.data = data;
	}

	public Data getData(){
		return data;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}

	public void setBLP6004500314(BLP6004500314 bLP6004500314){
		this.bLP6004500314 = bLP6004500314;
	}

	public BLP6004500314 getBLP6004500314(){
		return bLP6004500314;
	}

	public void setGAT7014100001(GAT7014100001 gAT7014100001){
		this.gAT7014100001 = gAT7014100001;
	}

	public GAT7014100001 getGAT7014100001(){
		return gAT7014100001;
	}

	public void setGRP7013800004(GRP7013800004 gRP7013800004){
		this.gRP7013800004 = gRP7013800004;
	}

	public GRP7013800004 getGRP7013800004(){
		return gRP7013800004;
	}

	public void setSAO6003401683(SAO6003401683 sAO6003401683){
		this.sAO6003401683 = sAO6003401683;
	}

	public SAO6003401683 getSAO6003401683(){
		return sAO6003401683;
	}

	public void setSAO6003402002(SAO6003402002 sAO6003402002){
		this.sAO6003402002 = sAO6003402002;
	}

	public SAO6003402002 getSAO6003402002(){
		return sAO6003402002;
	}

	public void setSAO6003401684(SAO6003401684 sAO6003401684){
		this.sAO6003401684 = sAO6003401684;
	}

	public SAO6003401684 getSAO6003401684(){
		return sAO6003401684;
	}

	public void setSAO6003401468(SAO6003401468 sAO6003401468){
		this.sAO6003401468 = sAO6003401468;
	}

	public SAO6003401468 getSAO6003401468(){
		return sAO6003401468;
	}

	@Override
 	public String toString(){
		return 
			"ProductInfo{" + 
			"code = '" + code + '\'' + 
			",data = '" + data + '\'' + 
			",status = '" + status + '\'' + 
			",bLP-60045-00314 = '" + bLP6004500314 + '\'' + 
			",gAT-70141-00001 = '" + gAT7014100001 + '\'' + 
			",gRP-70138-00004 = '" + gRP7013800004 + '\'' + 
			",sAO-60034-01683 = '" + sAO6003401683 + '\'' + 
			",sAO-60034-02002 = '" + sAO6003402002 + '\'' + 
			",sAO-60034-01684 = '" + sAO6003401684 + '\'' + 
			",sAO-60034-01468 = '" + sAO6003401468 + '\'' + 
			"}";
		}
}